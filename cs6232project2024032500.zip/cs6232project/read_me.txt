Admin Login
Username: Jane
Password: test1234

Employee Logins
Username: John
Password: test1234

Username: Rob
Password: test1234

Partially Complete Features
(This includes features that have been started but not comepleted)
- Admin reports
