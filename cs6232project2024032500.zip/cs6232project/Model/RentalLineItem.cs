﻿using System.Data;

namespace RentMe.Model;

/// <summary>
///  RentalLineItem model class
/// </summary>
public class RentalLineItem
{
    public int RentalID { get; set; }
    public int FurnitureID { get; set; }
    public string? Name { get; set; }
    public string? Description { get; set; }
    public int QuantityOwnedByStore { get; set; }
    public int QuantityRentedByStore {  get; set; }
    public double DailyRentalRate { get; set; }
    public string? Category {  get; set; }
    public string? Style {  get; set; }
    public int QuantityRentedByMember {  get; set; }
    public int QuantityReturnedByMember {  get; set; }
}